
import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import KeyAchievements from './components/KeyAchievements';
import Skills from './components/Skills';
import Experience from './components/Experience';
import Projects from './components/Projects';
import Education from './components/Education';
import Contact from './components/Contact';
import Footer from './components/Footer';

const App: React.FC = () => {
  return (
    <div className="min-h-screen bg-slate-900">
      <Header />
      <main className="container mx-auto max-w-5xl px-4 py-8 md:py-16">
        <div className="flex flex-col gap-20 md:gap-28">
          <Hero />
          <KeyAchievements />
          <Skills />
          <Experience />
          <Projects />
          <Education />
          <Contact />
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default App;
