
import React from 'react';

const Header: React.FC = () => {
  const navLinks = [
    { href: '#about', label: 'Ringkasan' },
    { href: '#achievements', label: 'Pencapaian' },
    { href: '#skills', label: 'Keahlian' },
    { href: '#experience', label: 'Pengalaman' },
    { href: '#projects', label: 'Proyek' },
    { href: '#education', label: 'Pendidikan' },
    { href: '#contact', label: 'Kontak' },
  ];

  return (
    <header className="bg-slate-900/80 backdrop-blur-sm sticky top-0 z-50">
      <nav className="container mx-auto max-w-5xl px-4">
        <div className="flex items-center justify-between h-16">
          <a href="#about" className="text-xl font-bold text-white hover:text-sky-400 transition-colors">
            Supriyadi
          </a>
          <ul className="hidden md:flex items-center space-x-4 lg:space-x-6">
            {navLinks.map((link) => (
              <li key={link.href}>
                <a
                  href={link.href}
                  className="text-slate-300 hover:text-sky-400 transition-colors font-medium text-sm"
                >
                  {link.label}
                </a>
              </li>
            ))}
          </ul>
        </div>
      </nav>
    </header>
  );
};

export default Header;
